    def setUp(self):
        self.aws_utils = AWSUtils(
            aws_access_key='AKIAIOSFODNN7EXAMPLE',
            aws_secret_key='wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
            region='us-east-1',
            cluster_name='test-cluster'
        )
