import unittest
from unittest.mock import MagicMock, patch
from src.utils.aws_utils import AWSUtils
from src.utils.report_generator import ReportGenerator

class TestAWSUtils(unittest.TestCase):
    def setUp(self):
        self.aws_utils = AWSUtils(
            aws_access_key='test',
            aws_secret_key='test',
            region='us-east-1',
            cluster_name='test-cluster'
        )

    @patch('boto3.client')
    def test_get_cluster_details(self, mock_boto3_client):
        # Mock EKS response
        mock_eks = MagicMock()
        mock_eks.describe_cluster.return_value = {
            'cluster': {
                'name': 'test-cluster',
                'version': '1.24',
                'status': 'ACTIVE',
                'endpoint': 'https://test.eks.amazonaws.com',
                'platformVersion': 'eks.1'
            }
        }
        mock_eks.list_nodegroups.return_value = {
            'nodegroups': ['test-ng']
        }
        mock_eks.describe_nodegroup.return_value = {
            'nodegroup': {
                'status': 'ACTIVE',
                'instanceTypes': ['t3.medium'],
                'scalingConfig': {
                    'desiredSize': 2,
                    'minSize': 1,
                    'maxSize': 4
                }
            }
        }
        
        mock_boto3_client.return_value = mock_eks
        
        result = self.aws_utils.get_cluster_details()
        
        self.assertEqual(result['cluster']['name'], 'test-cluster')
        self.assertEqual(result['cluster']['version'], '1.24')

class TestReportGenerator(unittest.TestCase):
    def setUp(self):
        self.report_generator = ReportGenerator()

    def test_generate_report(self):
        test_inputs = {
            "🔐 Security": {
                "IAM Configuration": "IRSA not implemented"
            }
        }
        
        test_cluster_details = {
            'cluster': {
                'name': 'test-cluster',
                'version': '1.24',
                'status': 'ACTIVE',
                'platform_version': 'eks.1'
            },
            'nodegroups': []
        }
        
        test_analysis_results = {
            'high_priority': [],
            'medium_priority': [],
            'low_priority': []
        }
        
        try:
            result = self.report_generator.generate_report(
                test_inputs,
                test_cluster_details,
                test_analysis_results
            )
            self.assertTrue(result.endswith('.pdf'))
        except Exception as e:
            self.fail(f"Report generation failed: {str(e)}")

if __name__ == '__main__':
    unittest.main()
