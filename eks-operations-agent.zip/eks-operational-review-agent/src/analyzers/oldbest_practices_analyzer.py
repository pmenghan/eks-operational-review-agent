import re
import requests
import logging
from bs4 import BeautifulSoup
from ..config.constants import BEST_PRACTICES_URLS

logger = logging.getLogger(__name__)

class EKSBestPracticesAnalyzer:
    def __init__(self):
        self.best_practices_urls = BEST_PRACTICES_URLS
        self.best_practices_cache = {}

    def analyze_cluster(self, cluster_details, inputs):
        """Comprehensive analysis of cluster state and configuration"""
        analysis_results = {
            'high_priority': [],
            'medium_priority': [],
            'low_priority': [],
            'recommendations': []
        }

        # Version analysis
        self._analyze_version(cluster_details['version_info'], analysis_results)

        # Networking analysis
        self._analyze_networking(cluster_details['networking'], analysis_results)

        # Security analysis
        self._analyze_security(cluster_details['security'], analysis_results)

        # Node group analysis
        self._analyze_nodegroups(cluster_details['nodegroups'], analysis_results)

        # Add-ons analysis
        self._analyze_addons(cluster_details['addons'], analysis_results)

        # Workload analysis
        self._analyze_workloads(cluster_details['workloads'], analysis_results)

        # Cost optimization analysis
        self._analyze_cost_optimization(cluster_details, inputs, analysis_results)

        # Reliability analysis
        self._analyze_reliability(cluster_details, inputs, analysis_results)

        # Performance analysis
        self._analyze_performance(cluster_details['metrics'], analysis_results)

        # Operational excellence analysis
        self._analyze_operational_excellence(cluster_details, inputs, analysis_results)

        return analysis_results

    def _analyze_version(self, version_info, results):
        if version_info['status'] == 'outdated':
            results['high_priority'].append({
                'category': 'Operations',
                'title': 'Kubernetes Version Upgrade Required',
                'description': f"Current version {version_info['current']} is behind latest {version_info['latest']}",
                'impact': 'Missing security patches and feature updates',
                'action_items': version_info['recommendations'][0]['action_items'],
                'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/update-cluster.html'
            })

    def _analyze_networking(self, networking, results):
        if not networking['endpoint_access'].get('private', False):
            results['medium_priority'].append({
                'category': 'Networking',
                'title': 'Cluster Endpoint Public Access',
                'description': 'Cluster API server is publicly accessible',
                'impact': 'Increased attack surface and potential security risk',
                'action_items': [
                    'Enable private access for the cluster endpoint',
                    'Restrict public access to specific IP ranges if needed',
                    'Use VPN or Direct Connect for secure cluster access'
                ],
                'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html'
            })

        if not networking['pod_networking'].get('custom_networking', False):
            results['medium_priority'].append({
                'category': 'Networking',
                'title': 'Custom Networking Not Enabled',
                'description': 'Default VPC CNI configuration in use',
                'impact': 'Limited IP address space and potential scaling issues',
                'action_items': [
                    'Enable custom networking for the VPC CNI',
                    'Configure larger CIDR blocks for pod IP addresses',
                    'Consider using prefix delegation for improved IP management'
                ],
                'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/cni-custom-network.html'
            })

    def _analyze_security(self, security, results):
        if not security['encryption'].get('secrets', False):
            results['high_priority'].append({
                'category': 'Security',
                'title': 'Kubernetes Secrets Not Encrypted',
                'description': 'Secrets are stored unencrypted in etcd',
                'impact': 'Sensitive data could be exposed if etcd is compromised',
                'action_items': [
                    'Enable envelope encryption for Kubernetes secrets',
                    'Use AWS KMS for key management',
                    'Rotate encryption keys regularly'
                ],
                'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/enable-secrets-encryption.html'
            })

        if not security['iam'].get('oidc_provider', False):
            results['high_priority'].append({
                'category': 'Security',
                'title': 'IAM Roles for Service Accounts Not Configured',
                'description': 'IRSA is not set up for the cluster',
                'impact': 'Pods may have overly broad permissions or use instance roles',
                'action_items': [
                    'Create an IAM OIDC provider for the cluster',
                    'Set up IAM roles for service accounts',
                    'Update applications to use IRSA'
                ],
                'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/iam-roles-for-service-accounts.html'
            })

    def _analyze_nodegroups(self, nodegroups, results):
        for ng in nodegroups:
            if ng['capacityType'] == 'ON_DEMAND':
                results['medium_priority'].append({
                    'category': 'Cost Optimization',
                    'title': f"Consider Spot Instances for Nodegroup {ng['name']}",
                    'description': 'Nodegroup uses only On-Demand instances',
                    'impact': 'Higher compute costs for workloads that can tolerate interruptions',
                    'action_items': [
                        'Evaluate workloads for Spot instance compatibility',
                        'Create a new nodegroup with Spot instances',
                        'Use Spot instance interruption handling'
                    ],
                    'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/managed-node-groups.html#managed-node-group-capacity-types'
                })

            if len(ng['subnets']) < 3:
                results['medium_priority'].append({
                    'category': 'Reliability',
                    'title': f"Improve Availability for Nodegroup {ng['name']}",
                    'description': 'Nodegroup not spread across all available AZs',
                    'impact': 'Reduced fault tolerance and potential for zonal failures',
                    'action_items': [
                        'Distribute nodegroup across at least 3 AZs',
                        'Update nodegroup configuration to use all available subnets',
                        'Consider using Karpenter for dynamic node provisioning'
                    ],
                    'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/create-managed-node-group.html'
                })

    def analyze_inputs(self, inputs):
        """Analyze user inputs against best practices"""
        if not self.best_practices_cache:
            self.fetch_best_practices()
        
        analysis_results = {
            'high_priority': [],
            'medium_priority': [],
            'low_priority': [],
            'recommendations': []
        }
        
        # Define comprehensive EKS best practices to check
        eks_best_practices = {
            'security': [
                {
                    'title': 'IAM Roles for Service Accounts',
                    'check': lambda x: 'irsa' in x.lower() or 'iam roles for service accounts' in x.lower(),
                    'recommendation': 'Implement IAM Roles for Service Accounts (IRSA) to manage pod-level permissions',
                    'priority': 'High'
                },
                {
                    'title': 'Pod Security Policies',
                    'check': lambda x: 'pod security' in x.lower(),
                    'recommendation': 'Configure Pod Security Policies to enforce security standards',
                    'priority': 'High'
                },
                {
                    'title': 'Secret Management',
                    'check': lambda x: 'secret rotation' in x.lower() and 'automated' in x.lower(),
                    'recommendation': 'Implement automated secret rotation using AWS Secrets Manager',
                    'priority': 'High'
                }
            ],
            'networking': [
                {
                    'title': 'Network Policies',
                    'check': lambda x: 'network polic' in x.lower(),
                    'recommendation': 'Implement Network Policies for pod-to-pod communication security',
                    'priority': 'High'
                },
                {
                    'title': 'CNI Version',
                    'check': lambda x: 'cni' in x.lower() and 'version' in x.lower(),
                    'recommendation': 'Ensure AWS VPC CNI is updated to the latest version',
                    'priority': 'Medium'
                },
                {
                    'title': 'Load Balancer Configuration',
                    'check': lambda x: 'load balancer' in x.lower() and 'controller' in x.lower(),
                    'recommendation': 'Configure AWS Load Balancer Controller with optimal settings',
                    'priority': 'Medium'
                }
            ],
            'reliability': [
                {
                    'title': 'Multi-AZ Deployment',
                    'check': lambda x: 'availability zone' in x.lower() or 'multi-az' in x.lower(),
                    'recommendation': 'Deploy workloads across multiple availability zones',
                    'priority': 'High'
                },
                {
                    'title': 'Pod Disruption Budgets',
                    'check': lambda x: 'disruption' in x.lower() or 'pdb' in x.lower(),
                    'recommendation': 'Implement Pod Disruption Budgets for critical workloads',
                    'priority': 'Medium'
                }
            ],
            'cost_optimization': [
                {
                    'title': 'Spot Instances Usage',
                    'check': lambda x: 'spot' in x.lower() and 'instance' in x.lower(),
                    'recommendation': 'Utilize Spot Instances for non-critical workloads',
                    'priority': 'Medium'
                },
                {
                    'title': 'Resource Requests and Limits',
                    'check': lambda x: 'resource' in x.lower() and ('request' in x.lower() or 'limit' in x.lower()),
                    'recommendation': 'Configure appropriate resource requests and limits for all containers',
                    'priority': 'High'
                },
                {
                    'title': 'Cluster Autoscaling',
                    'check': lambda x: 'autoscal' in x.lower(),
                    'recommendation': 'Implement Cluster Autoscaler or Karpenter for efficient resource management',
                    'priority': 'Medium'
                }
            ],
            'operations': [
                {
                    'title': 'Monitoring and Logging',
                    'check': lambda x: 'monitoring' in x.lower() or 'logging' in x.lower(),
                    'recommendation': 'Enable Container Insights and configure comprehensive logging',
                    'priority': 'High'
                },
                {
                    'title': 'Backup and Disaster Recovery',
                    'check': lambda x: 'backup' in x.lower() or 'disaster' in x.lower(),
                    'recommendation': 'Implement regular backup procedures and disaster recovery plans',
                    'priority': 'High'
                }
            ],
            'performance': [
                {
                    'title': 'HPA Configuration',
                    'check': lambda x: 'hpa' in x.lower() or 'horizontal pod autoscaling' in x.lower(),
                    'recommendation': 'Configure Horizontal Pod Autoscaling based on custom metrics',
                    'priority': 'Medium'
                },
                {
                    'title': 'Node Optimization',
                    'check': lambda x: 'node' in x.lower() and 'optim' in x.lower(),
                    'recommendation': 'Optimize node configurations for workload requirements',
                    'priority': 'Medium'
                }
            ],
            'compliance': [
                {
                    'title': 'Compliance Controls',
                    'check': lambda x: 'compliance' in x.lower() or 'audit' in x.lower(),
                    'recommendation': 'Implement compliance controls and regular auditing',
                    'priority': 'High'
                },
                {
                    'title': 'Data Protection',
                    'check': lambda x: 'data protection' in x.lower() or 'encryption' in x.lower(),
                    'recommendation': 'Enable encryption at rest and in transit for sensitive data',
                    'priority': 'High'
                }
            ]
        }

        # Check each best practice against inputs
        for category, practices in eks_best_practices.items():
            for practice in practices:
                is_implemented = False
                for section in inputs.values():
                    for content in section.values():
                        if isinstance(content, str) and practice['check'](content):
                            if any(compliant in content.lower() for compliant in ['implemented', 'enabled', 'configured', 'complete']):
                                is_implemented = True
                                break
                    
                if not is_implemented:
                    finding = {
                        'category': category,
                        'title': practice['title'],
                        'status': 'Non-compliant',
                        'recommendation': practice['recommendation'],
                        'priority': practice['priority']
                    }
                    
                    if practice['priority'] == 'High':
                        analysis_results['high_priority'].append(finding)
                    elif practice['priority'] == 'Medium':
                        analysis_results['medium_priority'].append(finding)
                    else:
                        analysis_results['low_priority'].append(finding)

        # Add cluster-specific recommendations
        self._add_cluster_specific_recommendations(inputs, analysis_results)
        
        return analysis_results

    def _add_cluster_specific_recommendations(self, inputs, analysis_results):
        """Add recommendations based on cluster-specific information"""
        cluster_info = inputs.get('📋 General Information', {}).get('Environment Details', '')
        
        # Version-related recommendations
        if 'version' in cluster_info.lower():
            version_match = re.search(r'Version:\s*([\d\.]+)', cluster_info)
            if version_match:
                version = version_match.group(1)
                if version < '1.30':
                    analysis_results['high_priority'].append({
                        'category': 'operations',
                        'title': 'Kubernetes Version Update',
                        'status': 'Action Required',
                        'recommendation': f'Update cluster from version {version} to the latest stable version',
                        'priority': 'High'
                    })

        # Node-related recommendations
        if 'node count' in cluster_info.lower():
            if 'node count: 1' in cluster_info.lower():
                analysis_results['high_priority'].append({
                    'category': 'reliability',
                    'title': 'Single Node Risk',
                    'status': 'Action Required',
                    'recommendation': 'Increase the number of nodes for high availability',
                    'priority': 'High'
                })

    def fetch_best_practices(self):
        """Fetch and parse best practices from AWS documentation"""
        for category, urls in self.best_practices_urls.items():
            try:
                if isinstance(urls, dict):
                    main_url = urls.get("main")
                    if main_url:
                        response = requests.get(main_url)
                        response.raise_for_status()
                        
                        # Store the URL itself as content if we can't parse it
                        self.best_practices_cache[category] = [{
                            'title': f'{category.replace("_", " ").title()} Best Practices',
                            'content': f'Refer to AWS documentation at: {main_url}',
                            'priority': self._determine_priority(category),
                            'url': main_url
                        }]
                        
                        # Try to parse if it's HTML
                        if 'text/html' in response.headers.get('content-type', ''):
                            soup = BeautifulSoup(response.text, 'html.parser')
                            self.best_practices_cache[category].extend(self._parse_content(soup))
                    
            except Exception as e:
                logger.error(f"Error fetching best practices for {category}: {e}")
                self.best_practices_cache[category] = [{
                    'title': f'{category.replace("_", " ").title()} Best Practices',
                    'content': 'Unable to fetch best practices. Please refer to AWS documentation.',
                    'priority': 'Medium'
                }]


    def _parse_content(self, soup):
        """Parse HTML content for best practices"""
        practices = []
        for section in soup.find_all(['h2', 'h3']):
            if self._is_valid_section(section.text):
                practice = {
                    'title': section.text.strip(),
                    'content': '',
                    'priority': self._determine_priority(section.text)
                }
                
                next_elem = section.find_next_sibling()
                while next_elem and next_elem.name not in ['h2', 'h3']:
                    if next_elem.text.strip():
                        practice['content'] += next_elem.text.strip() + '\n'
                    next_elem = next_elem.find_next_sibling()
                
                practices.append(practice)
        
        return practices

    def _is_valid_section(self, title):
        """Check if section is valid and not just a documentation heading"""
        invalid_patterns = [
            '¶', 'overview', 'introduction', 'how to use', 'further reading',
            'references', 'feedback', 'tools and resources', 'has moved', 'guide'
        ]
        return not any(pattern in title.lower() for pattern in invalid_patterns)

    def _determine_priority(self, title):
        """Determine priority based on keywords in title"""
        high_priority_keywords = ['security', 'encryption', 'authentication', 'critical']
        medium_priority_keywords = ['performance', 'optimization', 'monitoring']
        
        title_lower = title.lower()
        if any(keyword in title_lower for keyword in high_priority_keywords):
            return 'High'
        elif any(keyword in title_lower for keyword in medium_priority_keywords):
            return 'Medium'
        return 'Low'
    def _get_detailed_recommendations(self):
        """Get detailed recommendations with descriptions and action items"""
        return {
            'security': {
                'iam_roles': {
                    'title': 'IAM Roles for Service Accounts (IRSA)',
                    'category': 'Security',
                    'issue': 'Pod-level AWS permissions are not properly scoped',
                    'description': 'Pods may have excessive AWS permissions or use instance roles',
                    'action_items': [
                        'Create IAM roles for each Kubernetes service account',
                        'Annotate service accounts with the IAM role ARN',
                        'Update pod specs to use these service accounts',
                        'Implement least privilege access'
                    ],
                    'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/iam-roles-for-service-accounts.html',
                    'priority': 'High'
                },
                'pod_security': {
                    'title': 'Pod Security Policies (PSP)',
                    'category': 'Security',
                    'issue': 'No policies enforce security standards',
                    'description': 'Pods may run with excessive privileges or access sensitive resources',
                    'action_items': [
                        'Adopt Pod Security Admission (PSA) for Kubernetes >=1.25',
                        'Define policies for privileged access, root filesystem, capabilities',
                        'Implement pod security context constraints',
                        'Set up policy enforcement'
                    ],
                    'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/pod-security-standards.html',
                    'priority': 'High'
                },
                # Add more security recommendations...
            },
            'networking': {
                'network_policies': {
                    'title': 'Network Policies',
                    'category': 'Networking',
                    'issue': 'Unrestricted pod-to-pod communication',
                    'description': 'No network segmentation between pods and namespaces',
                    'action_items': [
                        'Use Calico or similar CNI supporting network policies',
                        'Define ingress/egress rules based on namespace and labels',
                        'Implement zero-trust networking model',
                        'Set up monitoring for policy violations'
                    ],
                    'reference': 'https://docs.aws.amazon.com/eks/latest/userguide/calico.html',
                    'priority': 'High'
                },
                # Add more networking recommendations...
            },
            # Add more categories...
        }
